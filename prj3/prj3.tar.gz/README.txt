Group Name: group mahi
Members:
Name:Manpreet Kaur
Student Number: 301294614.
The Pre-Assignment is in subdirectory context.
Candy-Factory code is in candy kids folder.